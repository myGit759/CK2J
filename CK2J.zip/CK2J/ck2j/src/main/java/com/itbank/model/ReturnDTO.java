package com.itbank.model;

public class ReturnDTO {

}
