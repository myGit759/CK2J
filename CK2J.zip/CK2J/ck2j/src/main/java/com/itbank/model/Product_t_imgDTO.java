package com.itbank.model;

public class Product_t_imgDTO {

	private String product_t_img;
	private int product_idx;
	
	public String getProduct_t_img() {
		return product_t_img;
	}
	public void setProduct_t_img(String product_t_img) {
		this.product_t_img = product_t_img;
	}
	public int getProduct_idx() {
		return product_idx;
	}
	public void setProduct_idx(int product_idx) {
		this.product_idx = product_idx;
	}
	
	
}
